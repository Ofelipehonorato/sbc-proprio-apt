# Instalação do SBC (Debian 13)

1. As fontes do SBC (uma vez): adicione o repositório de pacotes e instale as fontes do OpenSIPS e do
   rtpengine.

   ```
   curl -fsSL https://ofelipehonorato.github.io/sbc-proprio-apt/sbc.gpg -o /usr/share/keyrings/sbc.gpg
   echo "deb [signed-by=/usr/share/keyrings/sbc.gpg] https://ofelipehonorato.github.io/sbc-proprio-apt trixie main" > /etc/apt/sources.list.d/sbc.list
   apt update && apt install sbc-core-repos
   ```

2. O SBC: `apt update && apt install sbc-core`. Isso traz o módulo de kernel do rtpengine
   (`rtpengine-kernel-dkms`) e os cabeçalhos do kernel para compilá-lo. Sem o módulo o rtpengine não
   sobe, porque roda em modo kernel sem volta para o espaço de usuário. Antes do passo 3, confira:

   ```
   dkms status | grep rtpengine
   ```

   A linha precisa terminar em `installed`. Se terminar em `added`, rode
   `apt install linux-headers-$(uname -r)` e depois `dkms autoinstall`. Em VPS com o kernel "cloud" do
   Debian (o `uname -r` termina em `-cloud-amd64`), o pacote recomendado (`linux-headers-amd64`) não
   serve: é esse comando, com o `$(uname -r)`, que traz os cabeçalhos certos. A máquina precisa estar
   **sem Secure Boot** (ou com o módulo assinado): com ele ligado, o kernel recusa o módulo. O
   `sbcctl install` confere o módulo antes de começar.

3. A instalação, como root. O comando pede a senha do primeiro administrador (12 caracteres ou mais),
   sem mostrá-la. Num script, ela vai na primeira linha da entrada:

   ```
   sbcctl install -cliente "Nome do cliente" -interface ens18 -ip 10.0.0.5 \
     -admin-cidr 10.0.0.0/24 -licenca /root/licenca.json [-porta 8443] [-usuario admin]
   ```

   O `-admin-cidr` pode repetir. Só esses IPs chegam à API, ao painel e ao SSH. O comando recusa
   uma instalação que trancaria a sessão SSH atual fora, ou um IP que não está na interface. Confira
   os valores; o `-forcar` pula essa conferência.

   Rodar de novo é seguro: o que já foi feito não é refeito. Se a licença for recusada, corrija o
   arquivo e rode o mesmo comando outra vez.

4. O painel: `https://<IP de gestão>:8443/`, com certificado autoassinado. Entre com o usuário e com o
   TOTP que o `sbcctl install` mostrou. O segredo do TOTP só aparece uma vez.

Para trocar a licença depois: `sbcctl license install -arquivo /root/licenca-nova.json`.

Para remover: `apt remove sbc-core` para o `sbcd` e o `sbc-helper` e tira os programas. O OpenSIPS e o
rtpengine são de outros pacotes e continuam rodando; para pará-los também:
`systemctl disable --now opensips rtpengine-daemon`. O `apt purge` não apaga os
bancos (`sbcd` e `opensips`), o usuário `sbc` nem o `/var/lib/sbc`, para nenhum dado se perder sem
querer. Para reinstalar do zero, apague os bancos (`runuser -u postgres -- dropdb sbcd` e
`runuser -u postgres -- dropdb opensips`) e o `/etc/sbc`.
